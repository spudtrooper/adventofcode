package lib

import (
	"log"
	"regexp"
	"strings"

	"github.com/spudtrooper/adventofcode/common/must"
)

var (
	// --- scanner 4 ---
	scannerRE = regexp.MustCompile(`--- scanner (\d+) ---`)
	// 404,-588,-901
	coordRE = regexp.MustCompile(`([\-\+]?\d+),([\-\+]?\d+),([\-\+]?\d+)`)
)

type scanner struct {
	id      int
	beacons []coord
}
type coord struct {
	x, y, z int
}

func (c *coord) Equals(o coord) bool {
	return c.x == o.x && c.y == o.y && c.z == o.z
}

type orientation struct {
	dx, dy, dz int
}

var orientations = []orientation{
	{+1, +1, +1},
	{+1, -1, +1},
	{+1, +1, -1},
	{+1, -1, -1},
	{-1, -1, -1},
	{-1, -1, +1},
	{-1, +1, -1},
	{-1, +1, +1},
}

func comparesScanners(a, b scanner) {
	log.Printf("comparing %d vs %v", a.id, b.id)
	// acs := a.coords
}

func Part1FromString(input string) int {
	var scanners []*scanner
	for _, line := range strings.Split(input, "\n") {
		if m := scannerRE.FindStringSubmatch(line); len(m) == 2 {
			id := must.Atoi(m[1])
			s := &scanner{id: id}
			scanners = append(scanners, s)
		}
		if m := coordRE.FindStringSubmatch(line); len(m) == 4 {
			x, y, z := must.Atoi(m[1]), must.Atoi(m[2]), must.Atoi(m[3])
			s := scanners[len(scanners)-1]
			c := coord{x: x, y: y, z: z}
			s.beacons = append(s.beacons, c)
		}
	}

	if false {
		for _, s := range scanners {
			log.Println()
			log.Printf("--- scanner %d ---", s.id)
			for _, c := range s.beacons {
				log.Printf("%d,%d,%d", c.x, c.y, c.z)
			}
		}
	}

	for i, a := range scanners {
		for j, b := range scanners {
			if i >= j {
				continue
			}
			comparesScanners(*a, *b)
			break
		}
		break
	}

	return -1
}

func Part2FromString(input string) int {
	for _, line := range strings.Split(input, "\n") {
		// TODO
		if false {
			log.Println(line)
		}
	}
	return -1
}

func Part1(input string) int {
	return Part1FromString(must.ReadAllFile(input))
}

func Part2(input string) int {
	return Part2FromString(must.ReadAllFile(input))
}
